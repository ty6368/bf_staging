To utilize any of the SMS functions, you must first get an Access Token using oauth.jsp or oauthSS.jsp. Once received, oauth.jsp or oauthSS.jsp will save this access token as a session variable accessible to sms.jsp. To use the two-step standalone server consumption model, run oauth.jsp. To use the simpler client credentials consuption model, run oauthSS.jsp.

Installation:
	1. Install Apache Tomcat 7.0 web server and configure java environment.
	2. Deploy apigee-samples.war through Tomcat manager, or place contents in Tomcat directory under webapps/apigee-samples.
	3. Access each scriptlet by directing your browser to http://localhost:8080/apigee-samples/oauth.jsp, for example.

Configuration:
	1. Open oauth.jsp and enter your API Key and API Secret for variables clientId and clientSecret, respectively. 
	2. You may also wish to configure the oauth.jsp scriptlet for external access by changing the redirectUri variable in oauth.jsp to include your web server's external IP address. 	